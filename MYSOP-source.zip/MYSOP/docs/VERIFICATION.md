# MYSOP verification — 21 October 2026

MYSOP already includes a working browser interface served by FastAPI at `/`.
No replacement interface was needed.

## Results

- Started `bash scripts/start.sh` on port 8000 using the existing database.
- HTTP 200 for `/`, `/health`, `/static/app.js`, `/static/style.css`, `/docs` and `/openapi.json`. Health response: `{"status":"ok"}`.
- `.venv/bin/python -m pip check`: no broken requirements.
- `.venv/bin/python -m pytest -q`: **12 passed**. One upstream Starlette TestClient deprecation warning; no failures.
- `.venv/bin/python scripts/browser_smoke.py`: **passed** using real system Chromium, with desktop (1440×1000), tablet (1024×900) and phone (390×844) browser sessions.
- Browser workflow covered account registration, role invitations, guided SOP creation and ingredient costing, private drafts, supervisor submission, owner return/revision/approval, live delivery of published SOPs, staff preparation, acknowledgment persistence, publication of a second version, sign-out and signing back into the existing account. No JavaScript page errors or horizontal overflow.
- Automated workflow tests used temporary databases, separate from the running app's data.
- Shell syntax checks passed for installation and startup scripts.

The screenshots in this folder were refreshed by the browser test. They are
records of the working interface, not interactive previews.

## Browser access

No browser preview or inbound port-forwarding service is attached to this cloud
environment. Its internal port 8000 is reachable by tools within the environment,
but no working public preview URL is available. Binding to `0.0.0.0` alone does
not expose it to your browser. The process must be restarted if the cloud
environment stops or is restored.

For interactive testing, download and extract `MYSOP-source.zip`, install Python
3.12 or newer, run the installation/startup commands in
[OPEN_IN_BROWSER.md](OPEN_IN_BROWSER.md), then open `http://localhost:8000` on
that same computer. Register an account, create a team, create an SOP and choose
**Save & publish** as its owner. The published recipe appears in the SOP library.
Windows PowerShell commands are included in the guide; this verification ran
on Linux.

## GitHub preparation

The cloud checkout's `work` branch is based on the existing `origin/main`
commit, preserving repository history and the original placeholder file.
Project files are staged for review. No commit or push was made.

The source ZIP contains application code, tests, locked dependencies, scripts,
documentation and screenshots. It excludes Git metadata, virtual environments,
runtime databases, caches, logs and secrets. See the browser guide for cloning
the existing repository and saving these files on a new branch.
